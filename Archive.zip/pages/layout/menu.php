<ul class="menu">
    <li class="sidebar-title">Menu</li>
    <li class="sidebar-item <?php echo ($page == "users" ? "active" : "")?>">
        <a href="<?php echo ($page == "users" ? "index.php" : "../users")?>" class='sidebar-link'>
            <i class="bi bi-people"></i>
            <span>Users</span>
        </a>
    </li>
    <li class="sidebar-item <?php echo ($page == "populate_details" ? "active" : "")?>">
        <a href="<?php echo ($page == "populate_details" ? "index.php" : "../populate_details")?>" class='sidebar-link'>
            <i class="bi bi-grid-fill"></i>
            <span>Input Data Kamus</span>
        </a>
    </li>
</ul>
