<?php
    session_start();
    if($_SESSION['status'] !="sudah_login"){
        header("location:../errorpage/403.php");
    }
    $page = "populate_details";
    include '../../config/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kamus Enggano</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../skins/mazer/demo/assets/css/bootstrap.css">

    <link rel="stylesheet" href="../../skins/mazer/demo/assets/vendors/toastify/toastify.css">

    <link rel="stylesheet" href="../../skins/mazer/demo/assets/vendors/perfect-scrollbar/perfect-scrollbar.css">
    <link rel="stylesheet" href="../../skins/mazer/demo/assets/vendors/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="../../skins/mazer/demo/assets/css/app.css">
    <link rel="shortcut icon" href="../../skins/mazer/demo/assets/images/favicon.svg" type="image/x-icon">
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">
                    <div class="d-flex justify-content-between">
                        <div class="logo">
                            <a href="index.php"><img src="../../skins/mazer/demo/assets/images/logo/kamus_enggano.png" alt="Logo" srcset=""></a>
                        </div>
                        <div class="toggler">
                            <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sidebar-menu">
                    <?php
                        include '../layout/menu.php';
                    ?>
                </div>
                <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
            </div>
        </div>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

            <div class="page-heading">
                <div class="page-title">
                    <div class="row">
                        <div class="col-12 col-md-6 order-md-1 order-last">
                            <h3>Input Data Kamus</h3>
                            <p class="text-subtitle text-muted">Kamus BahasaEnggano</p>
                        </div>
                        <div class="col-12 col-md-6 order-md-2 order-first">
                            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Menu</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Input Data Kamus</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
                <section class="section">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Input Stem</h4>
                        </div>
                        <div class="card-body">
                            <?php
                                if(isset($_GET['pesan'])){?>
                                    <div class="col-sm-12 text-center">
                                        <div class="alert alert-primary" style="margin-top:15px;"><?php echo $_GET['pesan']; ?></div>
                                    </div>
                            <?php }?>
                            <form class="form form-horizontal" action="../../apps/kamusController.php?action=addData" method="POST">
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">Alphabet</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_Alphabet" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">Stem</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_Stem" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_homonymID</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_homonymID" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_remarks_optional</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_remarks_optional" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_variant</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_variant" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_dialect_variant</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_dialect_variant" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_source_form</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_source_form" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">sourceForm_homonymID</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_sourceForm_homonymID" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_etym_lang</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_etym_lang" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_etym_form</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_etym_form" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_etym_German</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_etym_German" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_crossRef</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_crossRef" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_German</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_German" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_English</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_English" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_German_crossRef</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_German_crossRef" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_loanword_lang</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_loanword_lang" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_loanword_form</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_loanword_form" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">examples</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_examples" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">examples_variant</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_examples_variant" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">examples_German</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_examples_German" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">examples_German_crossRef</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_examples_German_crossRef" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">examples_English</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_examples_English" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">example_etym_lang</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_example_etym_lang" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">example_etym_form</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_example_etym_form" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">stem_page_in_Kähler</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="kms_stem_page" placeholder="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe"></label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
                                            <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--<div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label style="color:#435ebe">Basa Kasar</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar" name="basa_kasar" placeholder="Basa Kasar">
                                                </div>
                                                <div class="col-md-4">
                                                    
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <input type="text" style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar_aksara" name="basa_kasar_aksara" placeholder="Aksara Bali">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-10 form-group">
                                                    <div class="form-group with-title mb-3">
                                                        <textarea style="border-color:#435ebe; color:#000000;" class="form-control" id="basa_kasar_kalimat" name="basa_kasar_kalimat" rows="2"></textarea>
                                                        <label style="border:1px solid #435ebe;">Contoh Kalimat</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-11 d-flex justify-content-end">
                                            <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
                                            <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                           
                                        </div>-->
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>

            </div>

            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-start">
                        <p>2021 &copy; Kamus Bahasa Bali</p>
                    </div>
                    <div class="float-end">
                        <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a
                                href="#">Team</a></p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="../../skins/mazer/demo/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="../../skins/mazer/demo/assets/js/bootstrap.bundle.min.js"></script>

    <script src="../../skins/mazer/demo/assets/vendors/toastify/toastify.js"></script>
    
    <script src="../../skins/mazer/demo/assets/js/main.js"></script>
    <script languange="javascript">
        function cekUnicode(){
            var str = document.getElementById('basa_kasar_aksara').value;
            for (var i = 0, n = str.length; i < n; i++) {
                if (str.charCodeAt( i ) > 255) { 
                    alert('true'); 
                }
            }
            alert('false');
        }
    </script>
    </div>
</body>

</html>